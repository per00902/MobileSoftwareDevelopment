package com.sleep.sleeptracker.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.sleep.sleeptracker.ui.screens.EditRecordScreen
import com.sleep.sleeptracker.ui.screens.HomeScreen
import com.sleep.sleeptracker.ui.screens.SettingsScreen
import com.sleep.sleeptracker.ui.screens.SleepTipsScreen

/**
 * 导航路由定义
 */
object Routes {
    const val HOME = "home"
    const val EDIT_RECORD = "edit_record?recordId={recordId}"
    const val SLEEP_TIPS = "sleep_tips"
    const val SETTINGS = "settings"

    fun editRecord(recordId: Long? = null): String {
        return if (recordId != null) {
            "edit_record?recordId=$recordId"
        } else {
            "edit_record"
        }
    }
}

@Composable
fun AppNavigation(
    modifier: Modifier = Modifier,
    navController: NavHostController = rememberNavController()
) {
    NavHost(
        navController = navController,
        startDestination = Routes.HOME,
        modifier = modifier
    ) {
        // 首页 - 睡眠记录列表
        composable(Routes.HOME) {
            HomeScreen(
                onNavigateToEdit = { recordId ->
                    navController.navigate(Routes.editRecord(recordId))
                },
                onNavigateToTips = {
                    navController.navigate(Routes.SLEEP_TIPS)
                },
                onNavigateToSettings = {
                    navController.navigate(Routes.SETTINGS)
                }
            )
        }

        // 新增/编辑睡眠记录
        composable(
            route = "edit_record?recordId={recordId}",
            arguments = listOf(
                navArgument("recordId") {
                    type = NavType.LongType
                    defaultValue = -1L
                }
            )
        ) { backStackEntry ->
            val recordId = backStackEntry.arguments?.getLong("recordId") ?: -1L
            EditRecordScreen(
                recordId = if (recordId == -1L) null else recordId,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // 睡眠建议（网络数据）
        composable(Routes.SLEEP_TIPS) {
            SleepTipsScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // 设置页面
        composable(Routes.SETTINGS) {
            SettingsScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
