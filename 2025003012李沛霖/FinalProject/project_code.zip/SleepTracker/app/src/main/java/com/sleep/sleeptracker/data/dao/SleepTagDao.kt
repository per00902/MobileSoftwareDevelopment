package com.sleep.sleeptracker.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.sleep.sleeptracker.data.entity.SleepTagEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SleepTagDao {

    /** 获取所有标签 */
    @Query("SELECT * FROM sleep_tags ORDER BY created_at DESC")
    fun getAllTags(): Flow<List<SleepTagEntity>>

    /** 根据ID获取标签 */
    @Query("SELECT * FROM sleep_tags WHERE id = :id")
    suspend fun getTagById(id: Long): SleepTagEntity?

    /** 按名称搜索标签 */
    @Query("SELECT * FROM sleep_tags WHERE name LIKE '%' || :keyword || '%'")
    fun searchTags(keyword: String): Flow<List<SleepTagEntity>>

    /** 插入标签 */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(tag: SleepTagEntity): Long

    /** 更新标签 */
    @Update
    suspend fun update(tag: SleepTagEntity)

    /** 删除标签 */
    @Delete
    suspend fun delete(tag: SleepTagEntity)
}
