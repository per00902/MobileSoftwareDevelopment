package com.sleep.sleeptracker.data.network

import com.sleep.sleeptracker.data.network.dto.SleepTipDto
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * 网络数据源 - 封装 Retrofit 实例和网络请求
 */
object NetworkDataSource {

    private const val BASE_URL = "https://jsonplaceholder.typicode.com/"

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val retrofit: Retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val apiService: ApiService = retrofit.create(ApiService::class.java)

    /**
     * 将 JSONPlaceholder 的 Post 数据映射为睡眠建议
     */
    fun mapToSleepTip(dto: SleepTipDto): SleepTip {
        val categories = listOf("睡眠环境", "作息规律", "饮食建议", "运动建议", "放松技巧")
        val category = categories[dto.id % categories.size]
        val imageUrls = listOf(
            "https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?w=400",
            "https://images.unsplash.com/photo-1511295742362-92c96b1cf484?w=400",
            "https://images.unsplash.com/photo-1541194577687-8c63bf9e7ee3?w=400",
            "https://images.unsplash.com/photo-1506377585622-bedcbb027af4?w=400",
            "https://images.unsplash.com/photo-1612878010854-1250dfc5000a?w=400"
        )

        return SleepTip(
            id = dto.id,
            title = (dto.title ?: "优质睡眠建议").take(30),
            description = (dto.body ?: "养成良好的睡眠习惯对健康至关重要。").take(200),
            category = category,
            imageUrl = imageUrls[dto.id % imageUrls.size]
        )
    }
}

/**
 * 睡眠建议数据模型（UI 层使用）
 */
data class SleepTip(
    val id: Int,
    val title: String,
    val description: String,
    val category: String,
    val imageUrl: String
)
