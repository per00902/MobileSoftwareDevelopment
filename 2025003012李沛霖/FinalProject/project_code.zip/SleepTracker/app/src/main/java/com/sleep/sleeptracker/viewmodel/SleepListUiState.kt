package com.sleep.sleeptracker.viewmodel

import com.sleep.sleeptracker.data.entity.SleepRecordEntity
import com.sleep.sleeptracker.data.entity.SleepTagEntity

/**
 * 睡眠记录列表 UiState
 */
data class SleepListUiState(
    val records: List<SleepRecordEntity> = emptyList(),
    val tags: List<SleepTagEntity> = emptyList(),
    val isLoading: Boolean = true,
    val isEmpty: Boolean = false,
    val searchQuery: String = "",
    val selectedTagId: Long? = null,
    val stats: SleepStats = SleepStats()
)

/**
 * 睡眠统计数据
 */
data class SleepStats(
    val averageDuration: Double = 0.0,    // 平均睡眠时长（分钟）
    val averageQuality: Double = 0.0,      // 平均质量（1-5）
    val recordCount: Int = 0,              // 最近记录数
    val targetHours: Int = 8,              // 目标小时
    val targetMinutes: Int = 0             // 目标分钟
)
