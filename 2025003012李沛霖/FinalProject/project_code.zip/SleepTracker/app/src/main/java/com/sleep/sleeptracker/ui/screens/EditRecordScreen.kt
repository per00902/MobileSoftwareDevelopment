package com.sleep.sleeptracker.ui.screens

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sleep.sleeptracker.data.entity.SleepTagEntity
import com.sleep.sleeptracker.ui.theme.SleepBad
import com.sleep.sleeptracker.ui.theme.SleepExcellent
import com.sleep.sleeptracker.ui.theme.SleepFair
import com.sleep.sleeptracker.ui.theme.SleepGood
import com.sleep.sleeptracker.ui.theme.SleepPoor
import com.sleep.sleeptracker.viewmodel.EditRecordUiState
import com.sleep.sleeptracker.viewmodel.EditRecordViewModel
import com.sleep.sleeptracker.viewmodel.SleepListViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditRecordScreen(
    recordId: Long?,
    onNavigateBack: () -> Unit,
    viewModel: EditRecordViewModel = viewModel(factory = EditRecordViewModel.Factory),
    listViewModel: SleepListViewModel = viewModel(factory = SleepListViewModel.Factory)
) {
    val uiState by viewModel.uiState.collectAsState()
    val sleepTime by viewModel.sleepTime.collectAsState()
    val wakeTime by viewModel.wakeTime.collectAsState()
    val quality by viewModel.quality.collectAsState()
    val note by viewModel.note.collectAsState()
    val selectedTagId by viewModel.selectedTagId.collectAsState()
    val tags by listViewModel.uiState.collectAsState()

    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val calendar = remember { Calendar.getInstance() }

    // 加载已有记录
    LaunchedEffect(recordId) {
        if (recordId != null && recordId > 0) {
            viewModel.loadRecord(recordId)
        }
    }

    // 处理保存结果
    LaunchedEffect(uiState) {
        when (val state = uiState) {
            is EditRecordUiState.SaveSuccess -> {
                listViewModel.refreshStats()
                onNavigateBack()
            }
            is EditRecordUiState.ValidationError -> {
                // 验证错误由 UI 直接展示
            }
            is EditRecordUiState.Error -> {
                // 错误由 UI 展示
            }
            else -> {}
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(if (recordId != null) "编辑记录" else "新增记录")
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // 入睡时间
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Bedtime,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "入睡时间",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = sleepTime?.let { formatDateTime(it) } ?: "未设置",
                            style = MaterialTheme.typography.bodyLarge
                        )
                        OutlinedButton(onClick = {
                            showDateTimePicker(context, calendar) { selectedTime ->
                                viewModel.onSleepTimeChanged(selectedTime)
                            }
                        }) {
                            Text("选择时间")
                        }
                    }
                }
            }

            // 起床时间
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.WbSunny,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.tertiary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "起床时间",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = wakeTime?.let { formatDateTime(it) } ?: "未设置",
                            style = MaterialTheme.typography.bodyLarge
                        )
                        OutlinedButton(onClick = {
                            showDateTimePicker(context, calendar) { selectedTime ->
                                viewModel.onWakeTimeChanged(selectedTime)
                            }
                        }) {
                            Text("选择时间")
                        }
                    }
                }
            }

            // 计算时长预览
            if (sleepTime != null && wakeTime != null && wakeTime!! > sleepTime!!) {
                val durationMinutes = (wakeTime!! - sleepTime!!) / 60000
                val hours = durationMinutes / 60
                val mins = durationMinutes % 60
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                    )
                ) {
                    Text(
                        text = "预计睡眠时长：${hours}小时${mins}分钟",
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            // 睡眠质量
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "睡眠质量",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = qualityStars(quality),
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Slider(
                        value = quality.toFloat(),
                        onValueChange = { viewModel.onQualityChanged(it.toInt()) },
                        valueRange = 1f..5f,
                        steps = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("很差", style = MaterialTheme.typography.labelSmall, color = SleepBad)
                        Text("很好", style = MaterialTheme.typography.labelSmall, color = SleepExcellent)
                    }
                }
            }

            // 标签选择
            if (tags.tags.isNotEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            "睡眠标签",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        TagSelector(
                            tags = tags.tags,
                            selectedTagId = selectedTagId,
                            onTagSelected = viewModel::onTagSelected
                        )
                    }
                }
            }

            // 备注
            OutlinedTextField(
                value = note,
                onValueChange = viewModel::onNoteChanged,
                label = { Text("备注（可选）") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 3,
                placeholder = { Text("记录一下今天的睡眠感受...") }
            )

            // 验证错误提示
            val validationError = uiState as? EditRecordUiState.ValidationError
            if (validationError != null) {
                Text(
                    text = validationError.message,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }

            // 保存按钮
            Button(
                onClick = viewModel::saveRecord,
                modifier = Modifier.fillMaxWidth(),
                enabled = uiState !is EditRecordUiState.Saving
            ) {
                if (uiState is EditRecordUiState.Saving) {
                    CircularProgressIndicator(
                        modifier = Modifier.padding(end = 8.dp),
                        strokeWidth = 2.dp
                    )
                }
                Text(if (recordId != null) "更新记录" else "保存记录")
            }

            // 错误提示
            val error = uiState as? EditRecordUiState.Error
            if (error != null) {
                Text(
                    text = error.message,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun TagSelector(
    tags: List<SleepTagEntity>,
    selectedTagId: Long?,
    onTagSelected: (Long?) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        tags.forEach { tag ->
            val isSelected = selectedTagId == tag.id
            Card(
                modifier = Modifier.weight(1f),
                onClick = {
                    onTagSelected(if (isSelected) null else tag.id)
                },
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.surface
                )
            ) {
                Text(
                    text = "${tag.emoji} ${tag.name}",
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary
                    else MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

private fun qualityStars(quality: Int): String {
    return when (quality) {
        1 -> "⭐"
        2 -> "⭐⭐"
        3 -> "⭐⭐⭐"
        4 -> "⭐⭐⭐⭐"
        5 -> "⭐⭐⭐⭐⭐"
        else -> "⭐⭐⭐"
    }
}

private fun formatDateTime(timestamp: Long): String {
    val sdf = SimpleDateFormat("yyyy年MM月dd日 HH:mm", Locale.getDefault())
    return sdf.format(Date(timestamp))
}

private fun showDateTimePicker(
    context: android.content.Context,
    calendar: Calendar,
    onTimeSelected: (Long) -> Unit
) {
    val year = calendar.get(Calendar.YEAR)
    val month = calendar.get(Calendar.MONTH)
    val day = calendar.get(Calendar.DAY_OF_MONTH)

    // 使用中文语言环境，确保日期选择器显示中文
    val config = android.content.res.Configuration(context.resources.configuration)
    config.setLocale(Locale.CHINESE)
    val chineseContext = context.createConfigurationContext(config)

    DatePickerDialog(chineseContext, { _, y, m, d ->
        calendar.set(y, m, d)
        TimePickerDialog(chineseContext, { _, hour, minute ->
            calendar.set(Calendar.HOUR_OF_DAY, hour)
            calendar.set(Calendar.MINUTE, minute)
            onTimeSelected(calendar.timeInMillis)
        }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show()
    }, year, month, day).show()
}
