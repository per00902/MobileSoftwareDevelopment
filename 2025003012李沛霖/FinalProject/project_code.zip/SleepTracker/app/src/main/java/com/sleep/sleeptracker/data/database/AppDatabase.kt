package com.sleep.sleeptracker.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.sleep.sleeptracker.data.dao.SleepRecordDao
import com.sleep.sleeptracker.data.dao.SleepTagDao
import com.sleep.sleeptracker.data.entity.SleepRecordEntity
import com.sleep.sleeptracker.data.entity.SleepTagEntity

@Database(
    entities = [SleepRecordEntity::class, SleepTagEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun sleepRecordDao(): SleepRecordDao
    abstract fun sleepTagDao(): SleepTagDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "sleep_tracker_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
