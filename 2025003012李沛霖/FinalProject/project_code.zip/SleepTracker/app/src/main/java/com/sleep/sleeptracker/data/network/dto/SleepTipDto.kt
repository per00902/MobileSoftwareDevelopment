package com.sleep.sleeptracker.data.network.dto

import com.google.gson.annotations.SerializedName

/**
 * 睡眠建议 DTO - 来自网络API的数据
 * JSONPlaceholder /posts 返回字段: userId, id, title, body
 */
data class SleepTipDto(
    @SerializedName("id")
    val id: Int,

    @SerializedName("title")
    val title: String?,

    @SerializedName("body")
    val body: String?
)
