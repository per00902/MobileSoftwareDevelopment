package com.sleep.sleeptracker.data.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * 睡眠标签表 - 存储用户自定义的睡眠标签（如：午睡、深度睡眠、失眠等）
 */
@Entity(tableName = "sleep_tags")
data class SleepTagEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    /** 标签名称 */
    @ColumnInfo(name = "name")
    val name: String,

    /** 标签图标emoji */
    @ColumnInfo(name = "emoji")
    val emoji: String = "🌙",

    /** 创建时间 */
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis()
)
