package com.sleep.sleeptracker.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.sleep.sleeptracker.data.entity.SleepRecordEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SleepRecordDao {

    /** 获取所有睡眠记录，按入睡时间倒序 */
    @Query("SELECT * FROM sleep_records ORDER BY sleep_time DESC")
    fun getAllRecords(): Flow<List<SleepRecordEntity>>

    /** 根据ID获取单条记录 */
    @Query("SELECT * FROM sleep_records WHERE id = :id")
    suspend fun getRecordById(id: Long): SleepRecordEntity?

    /** 按日期范围查询记录 */
    @Query("SELECT * FROM sleep_records WHERE sleep_time BETWEEN :startTime AND :endTime ORDER BY sleep_time DESC")
    fun getRecordsByDateRange(startTime: Long, endTime: Long): Flow<List<SleepRecordEntity>>

    /** 按标签ID查询记录 */
    @Query("SELECT * FROM sleep_records WHERE tag_id = :tagId ORDER BY sleep_time DESC")
    fun getRecordsByTagId(tagId: Long): Flow<List<SleepRecordEntity>>

    /** 搜索记录（按备注模糊搜索） */
    @Query("SELECT * FROM sleep_records WHERE note LIKE '%' || :keyword || '%' ORDER BY sleep_time DESC")
    fun searchRecords(keyword: String): Flow<List<SleepRecordEntity>>

    /** 统计最近N天的平均睡眠时长（分钟） */
    @Query("""
        SELECT AVG((wake_time - sleep_time) / 60000.0) 
        FROM sleep_records 
        WHERE sleep_time >= :sinceTime
    """)
    suspend fun getAverageSleepDuration(sinceTime: Long): Double?

    /** 统计最近N天的平均睡眠质量 */
    @Query("""
        SELECT AVG(CAST(quality AS REAL)) 
        FROM sleep_records 
        WHERE sleep_time >= :sinceTime
    """)
    suspend fun getAverageSleepQuality(sinceTime: Long): Double?

    /** 统计最近N天的记录数量 */
    @Query("SELECT COUNT(*) FROM sleep_records WHERE sleep_time >= :sinceTime")
    suspend fun getRecordCount(sinceTime: Long): Int

    /** 插入一条记录 */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(record: SleepRecordEntity): Long

    /** 更新记录 */
    @Update
    suspend fun update(record: SleepRecordEntity)

    /** 删除记录 */
    @Delete
    suspend fun delete(record: SleepRecordEntity)

    /** 根据ID删除记录 */
    @Query("DELETE FROM sleep_records WHERE id = :id")
    suspend fun deleteById(id: Long)
}
