package com.sleep.sleeptracker.viewmodel

import com.sleep.sleeptracker.data.network.SleepTip

/**
 * 睡眠建议 UiState - 表示网络请求的状态
 */
sealed interface SleepTipsUiState {
    data object Loading : SleepTipsUiState
    data class Success(val tips: List<SleepTip>) : SleepTipsUiState
    data class Error(val message: String) : SleepTipsUiState
    data object Empty : SleepTipsUiState
}
