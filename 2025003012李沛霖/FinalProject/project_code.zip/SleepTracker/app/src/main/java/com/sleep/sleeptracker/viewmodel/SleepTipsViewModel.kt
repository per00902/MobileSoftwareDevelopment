package com.sleep.sleeptracker.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.sleep.sleeptracker.data.repository.SleepRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SleepTipsViewModel(
    private val repository: SleepRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<SleepTipsUiState>(SleepTipsUiState.Loading)
    val uiState: StateFlow<SleepTipsUiState> = _uiState.asStateFlow()

    init {
        loadTips()
    }

    fun loadTips() {
        viewModelScope.launch {
            _uiState.value = SleepTipsUiState.Loading
            repository.fetchSleepTips().fold(
                onSuccess = { tips ->
                    _uiState.value = if (tips.isEmpty()) {
                        SleepTipsUiState.Empty
                    } else {
                        SleepTipsUiState.Success(tips)
                    }
                },
                onFailure = { error ->
                    _uiState.value = SleepTipsUiState.Error(
                        error.message ?: "网络请求失败，请检查网络连接"
                    )
                }
            )
        }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val application = this[APPLICATION_KEY]!!
                val database = com.sleep.sleeptracker.data.database.AppDatabase.getDatabase(application)
                val repository = SleepRepository(
                    database.sleepRecordDao(),
                    database.sleepTagDao()
                )
                SleepTipsViewModel(repository)
            }
        }
    }
}
