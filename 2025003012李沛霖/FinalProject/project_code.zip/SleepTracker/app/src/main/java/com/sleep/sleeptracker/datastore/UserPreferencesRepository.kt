package com.sleep.sleeptracker.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

// 顶层扩展属性，DataStore 单例
private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_preferences")

/**
 * DataStore 偏好设置 Repository
 * 保存用户偏好和最近状态
 */
class UserPreferencesRepository(private val context: Context) {

    companion object {
        // 用户偏好键
        val TARGET_SLEEP_HOURS = intPreferencesKey("target_sleep_hours")
        val TARGET_SLEEP_MINUTES = intPreferencesKey("target_sleep_minutes")
        val LAST_SEARCH_KEYWORD = stringPreferencesKey("last_search_keyword")
        val DEFAULT_SORT_ORDER = stringPreferencesKey("default_sort_order")
        val NOTIFICATION_ENABLED = booleanPreferencesKey("notification_enabled")
    }

    /** 目标睡眠时长（小时） - 默认8小时 */
    val targetSleepHours: Flow<Int> = context.dataStore.data.map { preferences ->
        preferences[TARGET_SLEEP_HOURS] ?: 8
    }

    /** 目标睡眠时长（分钟） - 默认0分钟 */
    val targetSleepMinutes: Flow<Int> = context.dataStore.data.map { preferences ->
        preferences[TARGET_SLEEP_MINUTES] ?: 0
    }

    /** 最近搜索关键词 */
    val lastSearchKeyword: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[LAST_SEARCH_KEYWORD] ?: ""
    }

    /** 默认排序方式 */
    val defaultSortOrder: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[DEFAULT_SORT_ORDER] ?: "time_desc"
    }

    /** 通知开关 */
    val notificationEnabled: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[NOTIFICATION_ENABLED] ?: true
    }

    /** 保存目标睡眠时长 */
    suspend fun saveTargetSleepTime(hours: Int, minutes: Int) {
        context.dataStore.edit { preferences ->
            preferences[TARGET_SLEEP_HOURS] = hours
            preferences[TARGET_SLEEP_MINUTES] = minutes
        }
    }

    /** 保存最近搜索关键词 */
    suspend fun saveLastSearchKeyword(keyword: String) {
        context.dataStore.edit { preferences ->
            preferences[LAST_SEARCH_KEYWORD] = keyword
        }
    }

    /** 保存默认排序方式 */
    suspend fun saveDefaultSortOrder(order: String) {
        context.dataStore.edit { preferences ->
            preferences[DEFAULT_SORT_ORDER] = order
        }
    }

    /** 保存通知开关 */
    suspend fun saveNotificationEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[NOTIFICATION_ENABLED] = enabled
        }
    }
}
