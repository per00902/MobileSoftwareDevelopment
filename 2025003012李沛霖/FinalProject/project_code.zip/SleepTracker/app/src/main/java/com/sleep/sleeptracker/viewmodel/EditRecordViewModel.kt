package com.sleep.sleeptracker.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.sleep.sleeptracker.data.entity.SleepRecordEntity
import com.sleep.sleeptracker.data.repository.SleepRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class EditRecordViewModel(
    private val repository: SleepRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<EditRecordUiState>(EditRecordUiState.Idle)
    val uiState: StateFlow<EditRecordUiState> = _uiState.asStateFlow()

    private val _sleepTime = MutableStateFlow<Long?>(null)
    val sleepTime: StateFlow<Long?> = _sleepTime.asStateFlow()

    private val _wakeTime = MutableStateFlow<Long?>(null)
    val wakeTime: StateFlow<Long?> = _wakeTime.asStateFlow()

    private val _quality = MutableStateFlow(3)
    val quality: StateFlow<Int> = _quality.asStateFlow()

    private val _note = MutableStateFlow("")
    val note: StateFlow<String> = _note.asStateFlow()

    private val _selectedTagId = MutableStateFlow<Long?>(null)
    val selectedTagId: StateFlow<Long?> = _selectedTagId.asStateFlow()

    private var editingRecordId: Long? = null

    /** 加载已有记录进行编辑 */
    fun loadRecord(recordId: Long) {
        viewModelScope.launch {
            val record = repository.getRecordById(recordId)
            if (record != null) {
                editingRecordId = record.id
                _sleepTime.value = record.sleepTime
                _wakeTime.value = record.wakeTime
                _quality.value = record.quality
                _note.value = record.note
                _selectedTagId.value = record.tagId
            }
        }
    }

    fun onSleepTimeChanged(time: Long) {
        _sleepTime.value = time
        _uiState.value = EditRecordUiState.Idle
    }

    fun onWakeTimeChanged(time: Long) {
        _wakeTime.value = time
        _uiState.value = EditRecordUiState.Idle
    }

    fun onQualityChanged(quality: Int) {
        _quality.value = quality
    }

    fun onNoteChanged(note: String) {
        _note.value = note
    }

    fun onTagSelected(tagId: Long?) {
        _selectedTagId.value = tagId
    }

    /** 保存记录（新增或更新） */
    fun saveRecord() {
        val sleep = _sleepTime.value
        val wake = _wakeTime.value

        // 输入验证
        if (sleep == null) {
            _uiState.value = EditRecordUiState.ValidationError("sleepTime", "请选择入睡时间")
            return
        }
        if (wake == null) {
            _uiState.value = EditRecordUiState.ValidationError("wakeTime", "请选择起床时间")
            return
        }
        if (wake <= sleep) {
            _uiState.value = EditRecordUiState.ValidationError("wakeTime", "起床时间必须晚于入睡时间")
            return
        }
        if (_quality.value < 1 || _quality.value > 5) {
            _uiState.value = EditRecordUiState.ValidationError("quality", "睡眠质量评级无效")
            return
        }

        _uiState.value = EditRecordUiState.Saving

        viewModelScope.launch {
            try {
                val record = SleepRecordEntity(
                    id = editingRecordId ?: 0,
                    sleepTime = sleep,
                    wakeTime = wake,
                    quality = _quality.value,
                    note = _note.value,
                    tagId = _selectedTagId.value
                )

                if (editingRecordId != null) {
                    repository.updateRecord(record)
                } else {
                    repository.insertRecord(record)
                }
                _uiState.value = EditRecordUiState.SaveSuccess
            } catch (e: Exception) {
                _uiState.value = EditRecordUiState.Error(e.message ?: "保存失败")
            }
        }
    }

    fun resetState() {
        _uiState.value = EditRecordUiState.Idle
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val application = this[APPLICATION_KEY]!!
                val database = com.sleep.sleeptracker.data.database.AppDatabase.getDatabase(application)
                val repository = SleepRepository(
                    database.sleepRecordDao(),
                    database.sleepTagDao()
                )
                EditRecordViewModel(repository)
            }
        }
    }
}
