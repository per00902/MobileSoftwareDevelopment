package com.sleep.sleeptracker.data.repository

import com.sleep.sleeptracker.data.dao.SleepRecordDao
import com.sleep.sleeptracker.data.dao.SleepTagDao
import com.sleep.sleeptracker.data.entity.SleepRecordEntity
import com.sleep.sleeptracker.data.entity.SleepTagEntity
import com.sleep.sleeptracker.data.network.NetworkDataSource
import com.sleep.sleeptracker.data.network.SleepTip
import kotlinx.coroutines.flow.Flow

/**
 * Repository - 隔离本地数据库和网络数据访问
 * ViewModel 通过此类访问数据，不直接调用 DAO 或网络
 */
class SleepRepository(
    private val recordDao: SleepRecordDao,
    private val tagDao: SleepTagDao
) {

    // ==================== 睡眠记录相关 ====================

    /** 获取所有睡眠记录 */
    fun getAllRecords(): Flow<List<SleepRecordEntity>> = recordDao.getAllRecords()

    /** 根据ID获取单条记录 */
    suspend fun getRecordById(id: Long): SleepRecordEntity? = recordDao.getRecordById(id)

    /** 按日期范围查询 */
    fun getRecordsByDateRange(startTime: Long, endTime: Long): Flow<List<SleepRecordEntity>> =
        recordDao.getRecordsByDateRange(startTime, endTime)

    /** 按标签查询 */
    fun getRecordsByTagId(tagId: Long): Flow<List<SleepRecordEntity>> =
        recordDao.getRecordsByTagId(tagId)

    /** 搜索记录 */
    fun searchRecords(keyword: String): Flow<List<SleepRecordEntity>> =
        recordDao.searchRecords(keyword)

    /** 获取平均睡眠时长（分钟） */
    suspend fun getAverageSleepDuration(sinceTime: Long): Double =
        recordDao.getAverageSleepDuration(sinceTime) ?: 0.0

    /** 获取平均睡眠质量 */
    suspend fun getAverageSleepQuality(sinceTime: Long): Double =
        recordDao.getAverageSleepQuality(sinceTime) ?: 0.0

    /** 获取记录数量 */
    suspend fun getRecordCount(sinceTime: Long): Int =
        recordDao.getRecordCount(sinceTime)

    /** 插入记录 */
    suspend fun insertRecord(record: SleepRecordEntity): Long =
        recordDao.insert(record)

    /** 更新记录 */
    suspend fun updateRecord(record: SleepRecordEntity) =
        recordDao.update(record)

    /** 删除记录 */
    suspend fun deleteRecord(record: SleepRecordEntity) =
        recordDao.delete(record)

    /** 根据ID删除 */
    suspend fun deleteRecordById(id: Long) =
        recordDao.deleteById(id)

    // ==================== 标签相关 ====================

    /** 获取所有标签 */
    fun getAllTags(): Flow<List<SleepTagEntity>> = tagDao.getAllTags()

    /** 搜索标签 */
    fun searchTags(keyword: String): Flow<List<SleepTagEntity>> = tagDao.searchTags(keyword)

    /** 插入标签 */
    suspend fun insertTag(tag: SleepTagEntity): Long = tagDao.insert(tag)

    /** 更新标签 */
    suspend fun updateTag(tag: SleepTagEntity) = tagDao.update(tag)

    /** 删除标签 */
    suspend fun deleteTag(tag: SleepTagEntity) = tagDao.delete(tag)

    // ==================== 网络相关 ====================

    /** 从网络获取睡眠建议 */
    suspend fun fetchSleepTips(): Result<List<SleepTip>> {
        return try {
            val dtos = NetworkDataSource.apiService.getSleepTips()
            val tips = dtos.take(10).map { NetworkDataSource.mapToSleepTip(it) }
            Result.success(tips)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
