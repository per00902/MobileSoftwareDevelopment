package com.sleep.sleeptracker.data.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * 睡眠记录表 - 存储每次睡眠的详细信息
 */
@Entity(tableName = "sleep_records")
data class SleepRecordEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    /** 入睡时间戳（毫秒） */
    @ColumnInfo(name = "sleep_time")
    val sleepTime: Long,

    /** 起床时间戳（毫秒） */
    @ColumnInfo(name = "wake_time")
    val wakeTime: Long,

    /** 睡眠质量评级 1-5（1=很差, 5=很好） */
    @ColumnInfo(name = "quality")
    val quality: Int = 3,

    /** 备注/日记 */
    @ColumnInfo(name = "note")
    val note: String = "",

    /** 记录创建时间 */
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),

    /** 关联的标签ID（外键） */
    @ColumnInfo(name = "tag_id")
    val tagId: Long? = null
)
