package com.sleep.sleeptracker.ui.theme

import androidx.compose.ui.graphics.Color

// Light theme colors - Soft night-inspired palette
val PrimaryLight = Color(0xFF3F51B5)       // Indigo
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFDBE1FF)
val OnPrimaryContainerLight = Color(0xFF001452)

val SecondaryLight = Color(0xFF585E71)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFDCE2F9)
val OnSecondaryContainerLight = Color(0xFF151B2C)

val TertiaryLight = Color(0xFF735572)
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFFED7FA)
val OnTertiaryContainerLight = Color(0xFF2B132C)

val BackgroundLight = Color(0xFFFBF8FF)
val OnBackgroundLight = Color(0xFF1B1B21)
val SurfaceLight = Color(0xFFFBF8FF)
val OnSurfaceLight = Color(0xFF1B1B21)
val SurfaceVariantLight = Color(0xFFE2E2EC)
val OnSurfaceVariantLight = Color(0xFF45464F)

val ErrorLight = Color(0xFFBA1A1A)
val OnErrorLight = Color(0xFFFFFFFF)

val OutlineLight = Color(0xFF757680)

// Dark theme colors
val PrimaryDark = Color(0xFFB4C5FF)
val OnPrimaryDark = Color(0xFF002372)
val PrimaryContainerDark = Color(0xFF24389B)
val OnPrimaryContainerDark = Color(0xFFDBE1FF)

val SecondaryDark = Color(0xFFC0C6DD)
val OnSecondaryDark = Color(0xFF2A3042)
val SecondaryContainerDark = Color(0xFF414659)
val OnSecondaryContainerDark = Color(0xFFDCE2F9)

val TertiaryDark = Color(0xFFE1BBDD)
val OnTertiaryDark = Color(0xFF422741)
val TertiaryContainerDark = Color(0xFF5A3D59)
val OnTertiaryContainerDark = Color(0xFFFED7FA)

val BackgroundDark = Color(0xFF131318)
val OnBackgroundDark = Color(0xFFE3E2E9)
val SurfaceDark = Color(0xFF131318)
val OnSurfaceDark = Color(0xFFE3E2E9)
val SurfaceVariantDark = Color(0xFF45464F)
val OnSurfaceVariantDark = Color(0xFFC5C6D0)

val ErrorDark = Color(0xFFFFB4AB)
val OnErrorDark = Color(0xFF690005)

val OutlineDark = Color(0xFF8F909A)

// Sleep quality colors
val SleepExcellent = Color(0xFF4CAF50)
val SleepGood = Color(0xFF8BC34A)
val SleepFair = Color(0xFFFFC107)
val SleepPoor = Color(0xFFFF9800)
val SleepBad = Color(0xFFF44336)
