package com.sleep.sleeptracker.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.sleep.sleeptracker.data.entity.SleepTagEntity
import com.sleep.sleeptracker.data.repository.SleepRepository
import com.sleep.sleeptracker.datastore.UserPreferencesRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SettingsUiState(
    val targetHours: Int = 8,
    val targetMinutes: Int = 0,
    val notificationEnabled: Boolean = true,
    val tags: List<SleepTagEntity> = emptyList(),
    val isSaving: Boolean = false,
    val saveMessage: String? = null
)

class SettingsViewModel(
    private val repository: SleepRepository,
    private val userPreferencesRepository: UserPreferencesRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    init {
        // 加载目标睡眠时长
        viewModelScope.launch {
            userPreferencesRepository.targetSleepHours.collect { hours ->
                _uiState.update { it.copy(targetHours = hours) }
            }
        }
        viewModelScope.launch {
            userPreferencesRepository.targetSleepMinutes.collect { minutes ->
                _uiState.update { it.copy(targetMinutes = minutes) }
            }
        }

        // 加载通知开关
        viewModelScope.launch {
            userPreferencesRepository.notificationEnabled.collect { enabled ->
                _uiState.update { it.copy(notificationEnabled = enabled) }
            }
        }

        // 加载标签列表
        viewModelScope.launch {
            repository.getAllTags().collect { tags ->
                _uiState.update { it.copy(tags = tags) }
            }
        }
    }

    fun onTargetHoursChanged(hours: Int) {
        _uiState.update { it.copy(targetHours = hours) }
    }

    fun onTargetMinutesChanged(minutes: Int) {
        _uiState.update { it.copy(targetMinutes = minutes) }
    }

    fun saveTargetSleepTime() {
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true) }
            userPreferencesRepository.saveTargetSleepTime(
                _uiState.value.targetHours,
                _uiState.value.targetMinutes
            )
            _uiState.update { it.copy(isSaving = false, saveMessage = "目标睡眠时长已保存") }
        }
    }

    fun onNotificationToggled(enabled: Boolean) {
        viewModelScope.launch {
            _uiState.update { it.copy(notificationEnabled = enabled) }
            userPreferencesRepository.saveNotificationEnabled(enabled)
        }
    }

    fun addTag(name: String, emoji: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            repository.insertTag(SleepTagEntity(name = name.trim(), emoji = emoji))
            _uiState.update { it.copy(saveMessage = "标签\"$name\"已添加") }
        }
    }

    fun deleteTag(tag: SleepTagEntity) {
        viewModelScope.launch {
            repository.deleteTag(tag)
        }
    }

    fun clearMessage() {
        _uiState.update { it.copy(saveMessage = null) }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val application = this[APPLICATION_KEY]!!
                val database = com.sleep.sleeptracker.data.database.AppDatabase.getDatabase(application)
                val repository = SleepRepository(
                    database.sleepRecordDao(),
                    database.sleepTagDao()
                )
                val userPreferencesRepository = UserPreferencesRepository(application)
                SettingsViewModel(repository, userPreferencesRepository)
            }
        }
    }
}
