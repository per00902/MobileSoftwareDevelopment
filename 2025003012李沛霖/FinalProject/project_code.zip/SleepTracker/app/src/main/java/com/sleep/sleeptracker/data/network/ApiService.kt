package com.sleep.sleeptracker.data.network

import com.sleep.sleeptracker.data.network.dto.SleepTipDto
import retrofit2.http.GET

/**
 * Retrofit API 接口定义
 * 使用 JSONPlaceholder 作为 Mock API 模拟睡眠建议数据
 * 实际返回的数据在 Repository 中做映射处理
 */
interface ApiService {

    /**
     * 获取睡眠建议列表
     * 使用 JSONPlaceholder 的 posts 接口模拟
     * 返回 10 条数据，在 Repository 中映射为睡眠建议
     */
    @GET("posts")
    suspend fun getSleepTips(): List<SleepTipDto>
}
