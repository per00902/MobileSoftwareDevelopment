package com.sleep.sleeptracker.viewmodel

/**
 * 编辑/新增记录 UiState
 */
sealed interface EditRecordUiState {
    data object Idle : EditRecordUiState
    data object Saving : EditRecordUiState
    data object SaveSuccess : EditRecordUiState
    data class Error(val message: String) : EditRecordUiState
    data class ValidationError(val field: String, val message: String) : EditRecordUiState
}
