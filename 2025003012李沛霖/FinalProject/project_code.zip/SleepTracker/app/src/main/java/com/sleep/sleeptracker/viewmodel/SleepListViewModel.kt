package com.sleep.sleeptracker.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.sleep.sleeptracker.data.entity.SleepRecordEntity
import com.sleep.sleeptracker.data.repository.SleepRepository
import com.sleep.sleeptracker.datastore.UserPreferencesRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Calendar

class SleepListViewModel(
    private val repository: SleepRepository,
    private val userPreferencesRepository: UserPreferencesRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SleepListUiState())
    val uiState: StateFlow<SleepListUiState> = _uiState.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    private val _selectedTagId = MutableStateFlow<Long?>(null)

    init {
        // 监听搜索和标签筛选变化，自动更新列表
        viewModelScope.launch {
            combine(_searchQuery, _selectedTagId) { query, tagId ->
                Pair(query, tagId)
            }.collect { (query, tagId) ->
                _uiState.update { it.copy(searchQuery = query, selectedTagId = tagId) }
            }
        }

        // 加载记录列表
        loadRecords()

        // 加载标签列表
        viewModelScope.launch {
            repository.getAllTags().collect { tags ->
                _uiState.update { it.copy(tags = tags) }
            }
        }

        // 加载统计数据
        loadStats()

        // 加载目标睡眠时长
        viewModelScope.launch {
            combine(
                userPreferencesRepository.targetSleepHours,
                userPreferencesRepository.targetSleepMinutes
            ) { hours, minutes ->
                Pair(hours, minutes)
            }.collect { (hours, minutes) ->
                _uiState.update {
                    it.copy(stats = it.stats.copy(targetHours = hours, targetMinutes = minutes))
                }
            }
        }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    private fun loadRecords() {
        viewModelScope.launch {
            combine(_searchQuery, _selectedTagId) { query, tagId ->
                Pair(query, tagId)
            }.flatMapLatest { (query, tagId) ->
                when {
                    query.isNotBlank() -> repository.searchRecords(query)
                    tagId != null -> repository.getRecordsByTagId(tagId)
                    else -> repository.getAllRecords()
                }
            }.collect { records ->
                _uiState.update {
                    it.copy(
                        records = records,
                        isLoading = false,
                        isEmpty = records.isEmpty()
                    )
                }
            }
        }
    }

    private fun loadStats() {
        viewModelScope.launch {
            val calendar = Calendar.getInstance()
            calendar.add(Calendar.DAY_OF_YEAR, -7)
            val sinceTime = calendar.timeInMillis

            val avgDuration = repository.getAverageSleepDuration(sinceTime)
            val avgQuality = repository.getAverageSleepQuality(sinceTime)
            val count = repository.getRecordCount(sinceTime)

            _uiState.update {
                it.copy(
                    stats = it.stats.copy(
                        averageDuration = avgDuration,
                        averageQuality = avgQuality,
                        recordCount = count
                    )
                )
            }
        }
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
        viewModelScope.launch {
            userPreferencesRepository.saveLastSearchKeyword(query)
        }
    }

    fun onTagFilterChanged(tagId: Long?) {
        _selectedTagId.value = tagId
    }

    fun deleteRecord(record: SleepRecordEntity) {
        viewModelScope.launch {
            repository.deleteRecord(record)
            loadStats()
        }
    }

    fun refreshStats() {
        loadStats()
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val application = this[APPLICATION_KEY]!!
                val database = com.sleep.sleeptracker.data.database.AppDatabase.getDatabase(application)
                val repository = SleepRepository(
                    database.sleepRecordDao(),
                    database.sleepTagDao()
                )
                val userPreferencesRepository = UserPreferencesRepository(application)
                SleepListViewModel(repository, userPreferencesRepository)
            }
        }
    }
}
